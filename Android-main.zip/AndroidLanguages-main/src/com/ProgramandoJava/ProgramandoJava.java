package com.ProgramandoJava;

public class ProgramandoJava {
	public static void main(String[] args){
	    int i = 2;
	    i++;
	    System.out.println(i);
	    ++i;
	    System.out.println(i);
	    System.out.println(++i);
	    System.out.println(i++);
	    System.out.println(i);
	  }
}
